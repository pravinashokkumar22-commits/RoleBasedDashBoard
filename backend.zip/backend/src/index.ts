import { app } from "./app";
import { pool } from "./db/db";


const cors = require("cors");

async function startServer() 
{
  try {
    await pool.query("SELECT 1");
    console.log("DB Connected");
    app.use(cors(  {origin: "http://localhost:process.env.FPORT", credentials: true} )); // Enable CORS for frontend
    app.listen(process.env.BPORT, () => {
      console.log(`Server running on http://localhost:${process.env.BPORT}`);
    });
  } catch (err) {
    console.error("DB Connection Failed:", err);
    process.exit(1);
  }
}
startServer();